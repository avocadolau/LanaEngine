#version 330 core

uniform vec4 pol_color;

out vec4 out_color;

void main() {
	out_color = pol_color;
}